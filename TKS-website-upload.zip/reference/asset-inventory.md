# TKS Engineering Works Reference Inventory

Source materials inspected:

- `reference/existing-website/Pasted text.txt`
- `reference/project-photos/TKS work photo.zip`
- `reference/project-photos/extracted/TKS work photo/*`
- `reference/logo/tks-logo.jpeg`
- Existing website content from `https://tksengworks.com/`, `/about/`, `/services/`, `/products/`, `/contact/`

Verified business facts from supplied/reference materials:

- Company: TKS Engineering Works
- Established: 2005 at Chennai, Tamil Nadu, India
- Services/products: Stainless Steel Gate, MS Gate, Stainless Steel Railing, Rolling Shutter, Metal Grill, Truss Work Service, Structural Roofing Service, Steel Fabrication Service, SS Fabrication Service, Metal Angle, Gazebo
- Email: `tksengneering2004@gmail.com`
- Phone: `+91 9840682818`
- Address: `No 64, Mugappair Rd, Padi, Chennai, Tamil Nadu 600058`
- Working hours: Mon-Fri 9 AM-6 PM, Saturday 9 AM-4 PM, Sunday Closed

Notes:

- The extracted archive contains real site/project photos plus one logo image and several service/product cards with embedded text.
- The real project photos are prioritized for hero, project cards, project gallery, about, services, and supporting sections.
- The old website is used as source-of-truth content, not as a visual template.

## Photo classification

1. `WhatsApp Image 2026-06-26 at 10.46.21 AM.jpeg`
   - Wide close-up of foundation/steel post bases.
   - Best use: supporting/process detail, fabrication detail.
   - Not ideal for hero.

2. `WhatsApp Image 2026-06-26 at 7.05.03 AM.jpeg`
   - Portrait exterior building/work area.
   - Best use: gallery.

3. `WhatsApp Image 2026-06-27 at 11.59.26 AM.jpeg`
   - Portrait railing/gate work in progress.
   - Best use: services/about secondary image.

4. `WhatsApp Image 2026-06-27 at 2.52.01 PM.jpeg`
   - Portrait railing/gate work.
   - Best use: gallery.

5. `WhatsApp Image 2026-06-27 at 2.52.39 PM.jpeg`
   - Portrait exterior walkway with railing.
   - Best use: project gallery.

6. `WhatsApp Image 2026-06-30 at 2.16.43 PM.jpeg`
   - Wide civil/steel base work area.
   - Best use: solutions/supporting section.

7. `WhatsApp Image 2026-07-04 at 2.57.48 PM.jpeg`
   - Wide interior installation/work in progress around equipment.
   - Best use: services/project card.

8. `WhatsApp Image 2026-07-04 at 5.34.36 PM.jpeg`
   - Wide installed equipment support frame.
   - Best use: solutions/services.

9. `WhatsApp Image 2026-07-04 at 5.34.54 PM.jpeg`
   - Wide installed equipment support frame, clean composition.
   - Best use: about/supporting.

10. `WhatsApp Image 2026-07-04 at 5.35.25 PM.jpeg`
    - Portrait equipment frame/installation.
    - Best use: gallery.

11. `WhatsApp Image 2026-07-04 at 6.41.42 AM.jpeg`
    - Portrait exterior railing/path.
    - Best use: gallery.

12. `WhatsApp Image 2026-07-04 at 9.00.58 AM.jpeg`
    - Wide equipment support frame in active work area.
    - Best use: services or supporting section.

13. `WhatsApp Image 2026-07-05 at 11.46.51 AM.jpeg`
    - Wide rooftop/worksite with steel materials.
    - Best use: process/supporting section.

14. `WhatsApp Image 2026-07-09 at 5.25.26 PM.jpeg`
    - Wide structural canopy/pergola detail.
    - Best use: featured project, services.

15. `WhatsApp Image 2026-07-09 at 5.25.40 PM.jpeg`
    - Wide completed/near-completed canopy frame.
    - Best use: homepage hero alternate, featured project.

16. `WhatsApp Image 2026-07-10 at 5.44.21 PM.jpeg`
    - Wide strong structural roofing/pergola frame.
    - Best use: primary homepage hero.

17. `WhatsApp Image 2026-07-13 at 11.29.19 AM.jpeg`
    - Wide large structural framework installation.
    - Best use: projects hero, featured project.

18. `WhatsApp Image 2026-07-15 at 5.06.17 PM.jpeg`
    - 4:3 rooftop/structural frame project.
    - Best use: services/featured project.

19. `WhatsApp Image 2026-07-16 at 4.19.38 PM.jpeg`
    - Wide decorative gate/grill.
    - Best use: services/gallery.

20. `WhatsApp Image 2026-07-18 at 5.47.14 PM.jpeg`
    - Wide building exterior with canopy/metalwork.
    - Best use: about or supporting section.

21. `WhatsApp Image 2026-07-24 at 9.10.36 AM.jpeg`
    - Portrait exterior walkway/gate/railing.
    - Best use: gallery.

22. `WhatsApp Image 2026-10-06 at 5.03.07 PM.jpeg`
    - TKS logo image.
    - Best use: logo/branding only.

23. `WhatsApp Image 2026-10-06 at 7.52.24 PM (1).jpeg`
    - Product/service card: Metal Angle.
    - Best use: service card image if needed.

24. `WhatsApp Image 2026-10-06 at 7.52.24 PM (2).jpeg`
    - Product/service card: Rolling Shutter.
    - Best use: service card image if needed.

25. `WhatsApp Image 2026-10-06 at 7.52.24 PM (3).jpeg`
    - Product/service card: SS Railing.
    - Best use: service card image if needed.

26. `WhatsApp Image 2026-10-06 at 7.52.24 PM.jpeg`
    - Product/service card: Steel Fabrication.
    - Best use: service card image if needed.

27. `WhatsApp Image 2026-10-06 at 7.52.25 PM (1).jpeg`
    - Product/service card: Railing Gate.
    - Best use: service card image if needed.

28. `WhatsApp Image 2026-10-06 at 7.52.25 PM (2).jpeg`
    - Portrait staircase/railing work.
    - Best use: services/gallery.

29. `WhatsApp Image 2026-10-06 at 7.52.25 PM (3).jpeg`
    - Product/service card: Design Grill.
    - Best use: service card image if needed.

30. `WhatsApp Image 2026-10-06 at 7.52.25 PM.jpeg`
    - Product/service card: SS Gate.
    - Best use: service card image if needed.

## Section choices

- Homepage hero: image 16, with image 17 as secondary project visual.
- About: images 9 and 20.
- Services: images 7, 8, 14, 19, 23-30 where service-specific visuals help.
- Solutions: images 1, 6, 12, 13.
- Featured projects: images 15, 16, 17, 18, 20.
- Project gallery: images 2-21 and 28, excluding the logo and avoiding overuse of embedded text cards.
- Supporting sections: images 1, 6, 12, 13.
